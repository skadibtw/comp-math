from typing import Any


def print_error_and_exit(message: Any) -> None:
    print(message)
    exit(1)
