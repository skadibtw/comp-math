from dots import Dots
from input import read_dots_from_stdin


def get_custom_function() -> Dots:
    return read_dots_from_stdin()
